package io.swagger.api;

import io.swagger.model.JsonApiBodyRequest;
import io.swagger.model.JsonApiBodyResponseErrors;
import io.swagger.model.JsonApiBodyResponseSuccess;
import io.swagger.model.RegistrarRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import io.swagger.api.Repository.UserRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-07-25T19:32:17.596Z")

@Controller
public class EliminarApiController implements EliminarApi {

	private static final Logger log = LoggerFactory.getLogger(EliminarApiController.class);

	private final ObjectMapper objectMapper;

	private final HttpServletRequest request;
	@Autowired
	UserRepository userRepository;

	@org.springframework.beans.factory.annotation.Autowired
	public EliminarApiController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	public ResponseEntity<?> eliminarIdDelete(@ApiParam(value = "id de la persona a eliminar", required = true) @PathVariable("id") String id) {
		JsonApiBodyResponseErrors responseErrors = new JsonApiBodyResponseErrors();
		JsonApiBodyResponseSuccess responseSuccess = new JsonApiBodyResponseSuccess();
		String accept = request.getHeader("Accept");
		RegistrarRequest persona = userRepository.findOne(id);

		if (accept != null && accept.contains("application/json")) {
			if (persona == null) {
				responseErrors.setCodigo("11");
				responseErrors.setDetalle("El usuario no existe");
				return new ResponseEntity<JsonApiBodyResponseErrors>(responseErrors, HttpStatus.CONFLICT);
			} else if (persona.getRol().equalsIgnoreCase("superadministradormaster")) {
				responseErrors.setCodigo("12");
				responseErrors.setDetalle("El usuario no se puede eliminar");
				return new ResponseEntity<JsonApiBodyResponseErrors>(responseErrors, HttpStatus.CONFLICT);
			} else {
				responseSuccess.setId(id);
				responseSuccess.setNombre(persona.getNombre());
				responseSuccess.setEstado(persona.getEstado());
				userRepository.delete(id);
				return new ResponseEntity<JsonApiBodyResponseSuccess>(responseSuccess, HttpStatus.OK);
			}

		}else {
			return new ResponseEntity<JsonApiBodyResponseSuccess>(HttpStatus.NOT_IMPLEMENTED);

		}
	}
}
